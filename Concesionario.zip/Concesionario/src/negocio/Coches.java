package negocio;


public class Coches{
	private String modelo;
	private static int cantidadCoches;
	private String marca;
	private int kilometros;
	private int anno;
	private double precio;
	
	

	public Coches(String modelo, String marca, int kilometros, int anno, double precio)
	{
		this.modelo = modelo;
		this.marca = marca;
		this.precio = precio;
		this.anno = anno;
		this.kilometros = kilometros;
		cantidadCoches++; //Incrementa la cuenta de cantidad de coches
	}


	public String getModelo(){
		return modelo;
	}

	public String getMarca(){
		return marca;
	}

	public int getAnno(){
		return anno;
	}

	public int getKilometros(){
		return kilometros;
	}

	public double getPrecio(){
		return precio;
	}

	public static int getCantidadCoches(){
		return cantidadCoches;
	}
}
