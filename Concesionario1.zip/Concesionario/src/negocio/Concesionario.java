package negocio;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Concesionario {
	public void Coches(){
	}
    	private ArrayList<Coches> listaCoches = new ArrayList<>();

    // Constructor: Inicializa la lista de coches cargando desde el archivo
    public Concesionario() {
        cargarCoches();  // Carga los coches desde "concesionario.csv"
    }

    // Método privado para cargar coches desde "concesionario.csv"
    private void cargarCoches() {
        Scanner sc = null;
        try {
            File fichero = new File("concesionario.csv");
            // Crea el archivo si no existe
            fichero.createNewFile();
            sc = new Scanner(fichero);
            sc.useDelimiter(",|\n"); // Delimitadores para comas y nuevas líneas

            while (sc.hasNext()){
                listaCoches.add(new Coches(sc.next(), sc.next(), sc.nextInt(), sc.nextInt(), sc.nextDouble()));
	   	}
	    
        } catch (IOException ex) {
            System.out.println("Error al cargar coches desde el archivo");
            System.out.println(ex);
        } finally {
            if (sc != null) sc.close();
        }
    }

    // Método público para añadir un coche y guardar en el archivo
    public void annadir(Coches coche) {
        listaCoches.add(coche);
        volcarCoches();
    }

    // Método privado para escribir los coches en listaCoches a "concesionario.csv"
    private void volcarCoches() {
        FileWriter fw = null;
        try {
            fw = new FileWriter("concesionario.csv"); // Sobrescribe el contenido existente
            for (Coches coche : listaCoches) {
                fw.write(coche.getModelo() + "," + coche.getMarca() + "," + coche.getAnno() + "," +
                         coche.getKilometros() + "," + coche.getPrecio() + "\n");
            }
        } catch (IOException ex) {
            System.out.println("Error al guardar coches en el archivo");
            System.out.println(ex);
        } finally {
            try {
                if (fw != null) fw.close();
            } catch (IOException ex) {
                System.out.println(ex);
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder strCoches = new StringBuilder();
        for (Coches coche : listaCoches) {
            strCoches.append(coche).append("\n");
        }
        return strCoches.toString();
    }
}
